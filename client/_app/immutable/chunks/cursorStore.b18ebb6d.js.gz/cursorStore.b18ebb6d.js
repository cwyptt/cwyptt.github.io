import{w as r}from"./index.b6a5c8fc.js";const s=r(!0);export{s as c};
